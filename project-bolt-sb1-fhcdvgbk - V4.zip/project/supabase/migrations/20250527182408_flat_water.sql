/*
  # Recipe Database Schema

  1. New Tables
    - `recipes`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `instructions` (text[])
      - `ingredients` (jsonb)
      - `prep_time` (integer)
      - `cook_time` (integer)
      - `servings` (integer)
      - `difficulty` (text)
      - `image_url` (text)
      - `created_at` (timestamptz)
      - `category` (text)
      - `meal_type` (text)
      - `cuisine_type` (text)
      - `tags` (text[])
      - `rating` (numeric)
      - `user_id` (uuid, foreign key)

  2. Security
    - Enable RLS on recipes table
    - Add policies for authenticated users to read all recipes
    - Add policy for users to manage their own recipes
*/

CREATE TABLE IF NOT EXISTS recipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  instructions text[] NOT NULL,
  ingredients jsonb NOT NULL,
  prep_time integer NOT NULL,
  cook_time integer NOT NULL,
  servings integer NOT NULL,
  difficulty text NOT NULL,
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  category text NOT NULL,
  meal_type text NOT NULL,
  cuisine_type text NOT NULL,
  tags text[] DEFAULT '{}',
  rating numeric DEFAULT 0,
  user_id uuid REFERENCES auth.users(id) NOT NULL
);

ALTER TABLE recipes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Recipes are viewable by everyone"
  ON recipes
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own recipes"
  ON recipes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own recipes"
  ON recipes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own recipes"
  ON recipes
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);