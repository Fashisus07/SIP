import React from 'react';
import { Search } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative bg-stone-900 overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center" 
        style={{ 
          backgroundImage: "url('https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')",
          opacity: 0.6
        }}
      ></div>
      
      <div className="relative container mx-auto px-4 py-20 md:py-32 flex flex-col items-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white text-center mb-6 max-w-4xl">
          Your Personal Kitchen Assistant
        </h1>
        <p className="text-xl text-white text-center mb-10 max-w-2xl">
          Find recipes, plan meals, and cook with confidence using our AI-powered kitchen companion
        </p>
        
        {/* Search Bar */}
        <div className="w-full max-w-2xl relative">
          <input
            type="text"
            placeholder="Search for recipes, ingredients, or cuisines..."
            className="w-full py-4 px-6 pl-12 rounded-full text-lg focus:outline-none focus:ring-2 focus:ring-red-600 shadow-lg"
          />
          <Search className="absolute left-4 top-4 h-6 w-6 text-stone-400" />
          <button className="absolute right-2 top-2 bg-red-600 text-white px-6 py-2 rounded-full hover:bg-red-700 transition-colors duration-200">
            Search
          </button>
        </div>
        
        {/* Quick category buttons */}
        <div className="flex flex-wrap justify-center gap-3 mt-8">
          {['Breakfast', 'Lunch', 'Dinner', 'Desserts', 'Vegetarian', 'Quick Meals'].map((category) => (
            <button
              key={category}
              className="bg-white bg-opacity-20 backdrop-filter backdrop-blur-sm text-white hover:bg-opacity-30 transition-all duration-200 px-4 py-2 rounded-full text-sm md:text-base"
            >
              {category}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Hero;