import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const signIn = useAuthStore((state) => state.signIn);

  const validateForm = () => {
    if (!email.trim()) {
      setError('Por favor, ingresa tu correo electrónico');
      return false;
    }
    if (!password.trim()) {
      setError('Por favor, ingresa tu contraseña');
      return false;
    }
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      setError('Por favor, ingresa un correo electrónico válido');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!validateForm()) {
      return;
    }

    try {
      await signIn(email.trim(), password);
      navigate('/home');
    } catch (err: any) {
      console.error('Login error:', err);
      if (err?.message?.includes('Email not confirmed')) {
        setError('Por favor, verifica tu correo electrónico antes de iniciar sesión. Revisa tu carpeta de spam si no encuentras el correo de confirmación.');
      } else if (err?.message?.includes('Invalid login credentials')) {
        setError('El correo electrónico o la contraseña son incorrectos. Por favor, verifica tus credenciales.');
      } else {
        setError('Ha ocurrido un error al iniciar sesión. Por favor, intenta nuevamente.');
      }
    }
  };

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-md mx-auto pt-8">
        <h1 className="text-2xl font-bold mb-2">¡Bienvenido!</h1>
        <p className="text-gray-600 mb-8">Por favor, inicia sesión para continuar</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Correo electrónico
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setError('');
              }}
              className="input-field"
              placeholder="tu@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Contraseña
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                className="input-field pr-10"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                {showPassword ? (
                  <EyeOff className="w-5 h-5 text-gray-400" />
                ) : (
                  <Eye className="w-5 h-5 text-gray-400" />
                )}
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            className="btn-primary w-full py-2 px-4 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
          >
            Iniciar Sesión
          </button>
        </form>

        <p className="text-center mt-6">
          ¿No tienes una cuenta?{' '}
          <a href="/register" className="text-orange-500 font-semibold hover:text-orange-600">
            Regístrate
          </a>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;