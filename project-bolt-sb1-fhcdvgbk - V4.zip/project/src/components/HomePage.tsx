import React, { useState } from 'react';
import { Search, ChevronRight, Menu as MenuIcon } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';

const HomePage = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { user, signOut } = useAuthStore();

  const categories = [
    { id: 1, name: 'Preparation Time', image: 'https://images.pexels.com/photos/4259707/pexels-photo-4259707.jpeg' },
    { id: 2, name: 'Meal Type', image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg' },
    { id: 3, name: 'Cuisine', image: 'https://images.pexels.com/photos/699953/pexels-photo-699953.jpeg' }
  ];

  const recommendedRecipes = [
    {
      id: 1,
      name: 'Milanesa',
      description: 'Savory Pastry Filled With Meat, Cheese, Or Vegetables.',
      difficulty: 'Middle level',
      time: '40 min',
      rating: 4.7,
      image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg'
    }
  ];

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="p-4">
        <div className="flex justify-between items-center mb-6">
          <button 
            className="p-2 rounded-full bg-gray-100"
            onClick={() => setIsMenuOpen(true)}
          >
            <MenuIcon className="w-6 h-6" />
          </button>
          <div className="w-10 h-10">
            <img src="/logo.png" alt="GastroBot" className="w-full h-full" />
          </div>
        </div>

        <h1 className="text-2xl font-semibold mb-6">Hola {user?.firstName}!</h1>

        <Link to="/search" className="block mb-8">
          <div className="flex items-center gap-3 p-3 bg-gray-100 rounded-xl">
            <Search className="w-5 h-5 text-gray-400" />
            <span className="text-gray-400">Explore recipes</span>
          </div>
        </Link>

        {/* Menu Overlay */}
        {isMenuOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
            <div className="fixed inset-y-0 left-0 w-80 bg-white shadow-lg p-6 transform transition-transform duration-300">
              <div className="flex flex-col h-full">
                <div className="flex justify-between items-center mb-8">
                  <h2 className="text-xl font-semibold">Menú</h2>
                  <button 
                    onClick={() => setIsMenuOpen(false)}
                    className="p-2 rounded-full hover:bg-gray-100"
                  >
                    <span className="sr-only">Close menu</span>
                    ×
                  </button>
                </div>

                <nav className="flex-1">
                  <div className="space-y-6">
                    <div className="border-b pb-4">
                      <h3 className="text-lg font-medium mb-2">Información de Perfil</h3>
                      <div className="space-y-2 text-sm text-gray-600">
                        <p>Nombre: {user?.firstName}</p>
                        <p>Apellido: {user?.lastName}</p>
                        <p>Email: {user?.email}</p>
                        <p>Teléfono: {user?.phone || 'No especificado'}</p>
                      </div>
                    </div>

                    <Link 
                      to="/favorites" 
                      className="block py-2 hover:text-orange-500 transition-colors"
                    >
                      Favoritos
                    </Link>

                    <Link 
                      to="/payment-methods" 
                      className="block py-2 hover:text-orange-500 transition-colors"
                    >
                      Medios de Pago
                    </Link>

                    <Link 
                      to="/recipe-history" 
                      className="block py-2 hover:text-orange-500 transition-colors"
                    >
                      Historial de Recetas
                    </Link>

                    <Link 
                      to="/settings" 
                      className="block py-2 hover:text-orange-500 transition-colors"
                    >
                      Configuración
                    </Link>
                  </div>
                </nav>

                <button
                  onClick={handleSignOut}
                  className="w-full py-3 text-center bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors mt-auto"
                >
                  Cerrar Sesión
                </button>
              </div>
            </div>
          </div>
        )}

        <section className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">All Categories</h2>
            <Link to="/categories" className="text-sm text-gray-500 flex items-center">
              See All
              <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {categories.map((category) => (
              <div key={category.id} className="relative rounded-xl overflow-hidden aspect-square">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-30 flex items-end p-2">
                  <span className="text-white text-sm font-medium">{category.name}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Recommended Recipes</h2>
            <Link to="/recommended" className="text-sm text-gray-500 flex items-center">
              See All
              <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="space-y-4">
            {recommendedRecipes.map((recipe) => (
              <div key={recipe.id} className="rounded-xl overflow-hidden">
                <img
                  src={recipe.image}
                  alt={recipe.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-1">{recipe.name}</h3>
                  <p className="text-gray-500 text-sm mb-3">{recipe.description}</p>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center">
                      <span className="text-orange-500">★</span>
                      <span className="ml-1">{recipe.rating}</span>
                    </div>
                    <span className="text-gray-500">|</span>
                    <span className="text-gray-500">{recipe.difficulty}</span>
                    <span className="text-gray-500">|</span>
                    <span className="text-gray-500">{recipe.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default HomePage;