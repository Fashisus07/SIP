import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const SplashScreen = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/login');
    }, 3000); // 3 seconds

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen relative">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('https://images.pexels.com/photos/6287295/pexels-photo-6287295.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')",
          filter: 'brightness(0.5)'
        }}
      ></div>
      
      {/* Logo Container */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-48 h-48 md:w-64 md:h-64 bg-white rounded-3xl shadow-2xl p-6 transform transition-all duration-500 hover:scale-105">
          <img
            src="/logo.png"
            alt="GastroBot"
            className="w-full h-full object-contain"
          />
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;