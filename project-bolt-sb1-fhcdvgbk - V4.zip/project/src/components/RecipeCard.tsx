import React from 'react';
import { Clock, User, Heart, BookmarkPlus } from 'lucide-react';

export interface Recipe {
  id: number;
  title: string;
  image: string;
  prepTime: number;
  cookTime: number;
  servings: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  tags: string[];
  rating: number;
}

interface RecipeCardProps {
  recipe: Recipe;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe }) => {
  const totalTime = recipe.prepTime + recipe.cookTime;
  
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300 group">
      {/* Image Section with overlay */}
      <div className="relative h-48 overflow-hidden">
        <img 
          src={recipe.image} 
          alt={recipe.title} 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        {/* Action buttons that appear on hover */}
        <div className="absolute bottom-2 right-2 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button className="bg-white p-1.5 rounded-full hover:bg-red-50 transition-colors duration-200">
            <Heart className="h-4 w-4 text-red-600" />
          </button>
          <button className="bg-white p-1.5 rounded-full hover:bg-red-50 transition-colors duration-200">
            <BookmarkPlus className="h-4 w-4 text-red-600" />
          </button>
        </div>
        
        {/* Difficulty badge */}
        <div className="absolute top-2 left-2">
          <span className={`text-xs px-2 py-1 rounded-full ${
            recipe.difficulty === 'Easy' ? 'bg-green-100 text-green-700' :
            recipe.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
            'bg-red-100 text-red-700'
          }`}>
            {recipe.difficulty}
          </span>
        </div>
      </div>
      
      {/* Content */}
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2 line-clamp-2">{recipe.title}</h3>
        
        {/* Recipe meta info */}
        <div className="flex justify-between text-sm text-stone-500 mb-3">
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            <span>{totalTime} min</span>
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 mr-1" />
            <span>{recipe.servings} serv</span>
          </div>
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <span key={i} className={`text-xs ${i < recipe.rating ? 'text-yellow-400' : 'text-stone-300'}`}>★</span>
            ))}
          </div>
        </div>
        
        {/* Tags */}
        <div className="flex flex-wrap gap-1 mt-2">
          {recipe.tags.slice(0, 3).map((tag, index) => (
            <span key={index} className="text-xs bg-stone-100 px-2 py-1 rounded-full text-stone-600">
              {tag}
            </span>
          ))}
          {recipe.tags.length > 3 && (
            <span className="text-xs bg-stone-100 px-2 py-1 rounded-full text-stone-600">
              +{recipe.tags.length - 3}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecipeCard;