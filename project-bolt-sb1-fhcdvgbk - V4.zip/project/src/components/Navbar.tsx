import React, { useState } from 'react';
import { ChefHat, Menu, X, Search, User } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <ChefHat className="h-8 w-8 text-red-600" />
            <span className="ml-2 font-bold text-xl">CookSmart</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#recipes" className="hover:text-red-600 transition-colors duration-200">Recipes</a>
            <a href="#meal-plans" className="hover:text-red-600 transition-colors duration-200">Meal Plans</a>
            <a href="#ingredients" className="hover:text-red-600 transition-colors duration-200">Ingredients</a>
            <a href="#tips" className="hover:text-red-600 transition-colors duration-200">Cooking Tips</a>
          </div>

          {/* Search and User Icon (Desktop) */}
          <div className="hidden md:flex items-center space-x-4">
            <button 
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2 rounded-full hover:bg-stone-100 transition-colors duration-200"
            >
              <Search className="h-5 w-5" />
            </button>
            <button className="p-2 rounded-full hover:bg-stone-100 transition-colors duration-200">
              <User className="h-5 w-5" />
            </button>
            <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors duration-200">
              Sign Up
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2 mr-2 rounded-full hover:bg-stone-100 transition-colors duration-200"
            >
              <Search className="h-5 w-5" />
            </button>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-full hover:bg-stone-100 transition-colors duration-200"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Search Bar (Both Mobile and Desktop) */}
        {isSearchOpen && (
          <div className="py-4 border-t border-stone-100 animate-fadeIn">
            <div className="relative">
              <input
                type="text"
                placeholder="Search recipes, ingredients..."
                className="w-full py-2 pl-10 pr-4 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-stone-400" />
            </div>
          </div>
        )}

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-stone-100 animate-fadeIn">
            <div className="flex flex-col py-4 space-y-4">
              <a href="#recipes" className="px-4 py-2 hover:bg-stone-100 rounded-lg transition-colors duration-200">Recipes</a>
              <a href="#meal-plans" className="px-4 py-2 hover:bg-stone-100 rounded-lg transition-colors duration-200">Meal Plans</a>
              <a href="#ingredients" className="px-4 py-2 hover:bg-stone-100 rounded-lg transition-colors duration-200">Ingredients</a>
              <a href="#tips" className="px-4 py-2 hover:bg-stone-100 rounded-lg transition-colors duration-200">Cooking Tips</a>
              <a href="#profile" className="px-4 py-2 hover:bg-stone-100 rounded-lg transition-colors duration-200">Profile</a>
              <button className="mx-4 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors duration-200">
                Sign Up
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;