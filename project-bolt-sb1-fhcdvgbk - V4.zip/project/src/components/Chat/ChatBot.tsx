import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Send, X } from 'lucide-react';
import { supabase, openai } from '../../lib/supabase';

interface Message {
  type: 'user' | 'bot';
  text: string;
}

const ChatBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { type: 'bot', text: '¡Hola! Soy GastroBot, tu asistente de cocina. ¿En qué puedo ayudarte?' }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const simulateTyping = async (text: string) => {
    setIsTyping(true);
    // Simular tiempo de escritura basado en la longitud del mensaje
    const delay = Math.min(1000 + text.length * 20, 3000);
    await new Promise(resolve => setTimeout(resolve, delay));
    setIsTyping(false);
    return text;
  };

  const processUserMessage = async (userMessage: string) => {
    try {
      const completion = await openai.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "Eres un asistente de cocina experto. Ayudas a los usuarios con recetas, técnicas de cocina y consejos culinarios. Respondes en español de manera amigable y profesional."
          },
          {
            role: "user",
            content: userMessage
          }
        ],
        model: "gpt-3.5-turbo",
      });

      return completion.choices[0].message.content || "Lo siento, no pude procesar tu mensaje.";
    } catch (error) {
      console.error('Error with OpenAI:', error);
      
      // Fallback a búsqueda en base de datos
      const { data: recipes } = await supabase
        .from('recipes')
        .select('*')
        .textSearch('title', userMessage);

      if (recipes && recipes.length > 0) {
        return `He encontrado algunas recetas que podrían interesarte:\n\n${
          recipes.slice(0, 3).map(recipe => `- ${recipe.title}`).join('\n')
        }`;
      }

      return 'Lo siento, hubo un problema al procesar tu mensaje. ¿Podrías intentarlo de nuevo?';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const userMessage = message.trim();
    setMessages(prev => [...prev, { type: 'user', text: userMessage }]);
    setMessage('');
    setIsTyping(true);

    try {
      const botResponse = await processUserMessage(userMessage);
      const formattedResponse = await simulateTyping(botResponse);
      setMessages(prev => [...prev, { type: 'bot', text: formattedResponse }]);
    } catch (error) {
      console.error('Error in chat:', error);
      const errorMessage = await simulateTyping('Lo siento, ocurrió un error. Por favor, intenta de nuevo.');
      setMessages(prev => [...prev, { type: 'bot', text: errorMessage }]);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-orange-500 text-white p-4 rounded-full shadow-lg hover:bg-orange-600 transition-colors"
      >
        <MessageSquare className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 w-[350px] bg-white rounded-xl shadow-xl">
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="font-semibold">GastroBot</h3>
        <div className="flex gap-2">
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-gray-100 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="h-[400px] overflow-y-auto p-4 space-y-4">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`chat-bubble ${
              msg.type === 'user' ? 'chat-bubble-user' : 'chat-bubble-bot'
            }`}
          >
            {msg.text}
          </div>
        ))}
        {isTyping && (
          <div className="chat-bubble chat-bubble-bot">
            <div className="flex space-x-2">
              <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex gap-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Escribe tu mensaje..."
            className="flex-1 p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            disabled={isTyping}
          />
          <button
            type="submit"
            className="p-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors disabled:bg-gray-300"
            disabled={isTyping}
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatBot;