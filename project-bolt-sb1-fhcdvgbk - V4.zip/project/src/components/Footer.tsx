import React from 'react';
import { ChefHat, Instagram, Twitter, Facebook, Youtube } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-stone-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-1">
            <div className="flex items-center mb-4">
              <ChefHat className="h-8 w-8 text-red-500" />
              <span className="ml-2 font-bold text-xl">CookSmart</span>
            </div>
            <p className="text-stone-400 mb-4">
              Your AI-powered kitchen assistant that makes cooking easy, efficient, and enjoyable.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Explore</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Recipes</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Meal Plans</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Ingredients</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Cooking Tips</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Cuisines</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">About Us</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Blog</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Careers</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Press</a></li>
              <li><a href="#" className="text-stone-400 hover:text-white transition-colors duration-200">Contact</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Subscribe</h3>
            <p className="text-stone-400 mb-4">
              Get weekly recipes and cooking tips straight to your inbox.
            </p>
            <div className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="px-4 py-2 bg-stone-800 rounded-l-lg focus:outline-none focus:ring-1 focus:ring-red-500 flex-grow"
              />
              <button className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-r-lg transition-colors duration-200">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-stone-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-stone-400 text-sm mb-4 md:mb-0">
            © 2025 CookSmart. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-stone-400 hover:text-white text-sm transition-colors duration-200">Privacy Policy</a>
            <a href="#" className="text-stone-400 hover:text-white text-sm transition-colors duration-200">Terms of Service</a>
            <a href="#" className="text-stone-400 hover:text-white text-sm transition-colors duration-200">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;