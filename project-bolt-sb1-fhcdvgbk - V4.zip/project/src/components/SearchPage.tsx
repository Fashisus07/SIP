import React, { useState, useEffect } from 'react';
import { ArrowLeft, X, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';

interface Recipe {
  id: string;
  title: string;
  rating: number;
  image_url: string;
  category: string;
  meal_type: string;
  cuisine_type: string;
}

const SearchPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [filteredRecipes, setFilteredRecipes] = useState<Recipe[]>([]);
  const [selectedFilter, setSelectedFilter] = useState('');
  const [activeFilterType, setActiveFilterType] = useState<'category' | 'meal_type' | 'cuisine_type' | null>(null);

  const categories = ['Pastas', 'Hamburguesas', 'Pizza', 'Carnes', 'Ensaladas', 'Sopas'];
  const mealTypes = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena'];
  const cuisineTypes = ['Italiana', 'Argentina', 'Mexicana', 'China', 'Japonesa'];

  useEffect(() => {
    fetchRecipes();
  }, []);

  const fetchRecipes = async () => {
    try {
      const { data, error } = await supabase
        .from('recipes')
        .select('*');
      
      if (error) throw error;
      setRecipes(data || []);
      setFilteredRecipes(data || []);
    } catch (error) {
      console.error('Error fetching recipes:', error);
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    filterRecipes(query, selectedFilter, activeFilterType);
  };

  const handleFilterClick = (filter: string, type: 'category' | 'meal_type' | 'cuisine_type') => {
    if (selectedFilter === filter && activeFilterType === type) {
      setSelectedFilter('');
      setActiveFilterType(null);
      filterRecipes(searchQuery, '', null);
    } else {
      setSelectedFilter(filter);
      setActiveFilterType(type);
      filterRecipes(searchQuery, filter, type);
    }
  };

  const filterRecipes = (query: string, filter: string, filterType: 'category' | 'meal_type' | 'cuisine_type' | null) => {
    let filtered = [...recipes];

    if (query) {
      filtered = filtered.filter(recipe =>
        recipe.title.toLowerCase().includes(query.toLowerCase())
      );
    }

    if (filter && filterType) {
      filtered = filtered.filter(recipe =>
        recipe[filterType].toLowerCase() === filter.toLowerCase()
      );
    }

    setFilteredRecipes(filtered);
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="p-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/home" className="p-2 rounded-full bg-gray-100">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Buscar Recetas</h1>
        </div>

        <div className="relative mb-4">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Buscar recetas..."
            className="w-full p-3 pl-4 pr-10 bg-gray-100 rounded-xl"
          />
          {searchQuery && (
            <button 
              onClick={() => handleSearch('')}
              className="absolute right-3 top-1/2 transform -translate-y-1/2"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          )}
        </div>

        {/* Filtros */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Filter className="w-4 h-4" />
            <span className="font-medium">Filtros</span>
          </div>
          
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-gray-500">Categorías:</span>
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => handleFilterClick(category, 'category')}
                  className={`px-3 py-1 rounded-full text-sm ${
                    selectedFilter === category && activeFilterType === 'category'
                      ? 'bg-orange-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-gray-500">Tipo de comida:</span>
              {mealTypes.map((type) => (
                <button
                  key={type}
                  onClick={() => handleFilterClick(type, 'meal_type')}
                  className={`px-3 py-1 rounded-full text-sm ${
                    selectedFilter === type && activeFilterType === 'meal_type'
                      ? 'bg-orange-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-gray-500">Cocina:</span>
              {cuisineTypes.map((type) => (
                <button
                  key={type}
                  onClick={() => handleFilterClick(type, 'cuisine_type')}
                  className={`px-3 py-1 rounded-full text-sm ${
                    selectedFilter === type && activeFilterType === 'cuisine_type'
                      ? 'bg-orange-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Resultados */}
        <div className="space-y-4">
          {filteredRecipes.map((recipe) => (
            <div key={recipe.id} className="flex items-center gap-4 bg-white rounded-xl p-3 shadow-sm">
              <img
                src={recipe.image_url}
                alt={recipe.title}
                className="w-20 h-20 rounded-lg object-cover"
              />
              <div>
                <h3 className="font-medium">{recipe.title}</h3>
                <div className="flex items-center mt-1">
                  <span className="text-orange-500">★</span>
                  <span className="ml-1 text-sm text-gray-600">{recipe.rating}</span>
                </div>
                <div className="flex gap-2 mt-1">
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                    {recipe.category}
                  </span>
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                    {recipe.meal_type}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SearchPage;