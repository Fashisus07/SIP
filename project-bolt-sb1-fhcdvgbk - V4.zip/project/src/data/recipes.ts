import { Recipe } from '../components/RecipeCard';

export const featuredRecipes: Recipe[] = [
  {
    id: 1,
    title: "Creamy Garlic Parmesan Risotto",
    image: "https://images.pexels.com/photos/5419336/pexels-photo-5419336.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    prepTime: 10,
    cookTime: 25,
    servings: 4,
    difficulty: "Medium",
    tags: ["Italian", "Rice", "Vegetarian", "Dinner"],
    rating: 4
  },
  {
    id: 2,
    title: "Spicy Thai Basil Chicken",
    image: "https://images.pexels.com/photos/699953/pexels-photo-699953.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    prepTime: 15,
    cookTime: 10,
    servings: 2,
    difficulty: "Easy",
    tags: ["Thai", "Chicken", "Spicy", "Quick"],
    rating: 5
  },
  {
    id: 3,
    title: "Classic Margherita Pizza",
    image: "https://images.pexels.com/photos/905847/pexels-photo-905847.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    prepTime: 20,
    cookTime: 15,
    servings: 3,
    difficulty: "Easy",
    tags: ["Italian", "Pizza", "Vegetarian"],
    rating: 4
  },
  {
    id: 4,
    title: "Hearty Beef and Vegetable Stew",
    image: "https://images.pexels.com/photos/5419313/pexels-photo-5419313.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    prepTime: 20,
    cookTime: 90,
    servings: 6,
    difficulty: "Medium",
    tags: ["Beef", "Comfort Food", "Winter", "Slow Cook"],
    rating: 5
  },
  {
    id: 5,
    title: "Fresh Avocado and Shrimp Salad",
    image: "https://images.pexels.com/photos/1211887/pexels-photo-1211887.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    prepTime: 15,
    cookTime: 5,
    servings: 2,
    difficulty: "Easy",
    tags: ["Salad", "Seafood", "Healthy", "Quick"],
    rating: 4
  },
  {
    id: 6,
    title: "Chocolate Lava Cake",
    image: "https://images.pexels.com/photos/4110001/pexels-photo-4110001.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    prepTime: 15,
    cookTime: 12,
    servings: 4,
    difficulty: "Medium",
    tags: ["Dessert", "Chocolate", "Baking"],
    rating: 5
  }
];