import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const openaiKey = import.meta.env.VITE_OPENAI_API_KEY;

if (!supabaseUrl) throw new Error('Missing VITE_SUPABASE_URL');
if (!supabaseAnonKey) throw new Error('Missing VITE_SUPABASE_ANON_KEY');

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

// Initialize OpenAI only if API key is available
export const openai = openaiKey ? new OpenAI({
  apiKey: openaiKey,
  dangerouslyAllowBrowser: true
}) : null;

// Función para insertar recetas
export const insertRecipes = async () => {
  const recipes = [
    {
      title: "Spaghetti a la Carbonara",
      description: "Pasta italiana clásica con salsa de huevo y panceta",
      instructions: ["Cocinar la pasta", "Preparar la salsa", "Mezclar todo"],
      ingredients: { 
        "spaghetti": "400g",
        "huevos": "3",
        "panceta": "200g",
        "queso_pecorino": "100g"
      },
      prep_time: 15,
      cook_time: 20,
      servings: 4,
      difficulty: "Media",
      image_url: "https://images.pexels.com/photos/1527603/pexels-photo-1527603.jpeg",
      category: "Pastas",
      meal_type: "Almuerzo",
      cuisine_type: "Italiana",
      tags: ["pasta", "italiana", "clásica"],
      rating: 4.8
    },
    {
      title: "Hamburguesa Clásica",
      description: "Hamburguesa casera con carne premium",
      instructions: ["Preparar la carne", "Armar la hamburguesa"],
      ingredients: {
        "carne_molida": "200g",
        "pan": "1 unidad",
        "lechuga": "2 hojas",
        "tomate": "2 rodajas"
      },
      prep_time: 10,
      cook_time: 15,
      servings: 1,
      difficulty: "Fácil",
      image_url: "https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg",
      category: "Hamburguesas",
      meal_type: "Cena",
      cuisine_type: "Argentina",
      tags: ["hamburguesa", "carne", "rápida"],
      rating: 4.5
    },
    {
      title: "Pizza Margherita",
      description: "Pizza italiana tradicional",
      instructions: ["Preparar la masa", "Agregar ingredientes", "Hornear"],
      ingredients: {
        "harina": "500g",
        "tomate": "300g",
        "mozzarella": "200g",
        "albahaca": "al gusto"
      },
      prep_time: 30,
      cook_time: 20,
      servings: 4,
      difficulty: "Media",
      image_url: "https://images.pexels.com/photos/905847/pexels-photo-905847.jpeg",
      category: "Pizza",
      meal_type: "Cena",
      cuisine_type: "Italiana",
      tags: ["pizza", "italiana", "vegetariana"],
      rating: 4.9
    }
  ];

  for (const recipe of recipes) {
    const { error } = await supabase
      .from('recipes')
      .insert([{ ...recipe, user_id: 'system' }]);
    
    if (error) console.error('Error inserting recipe:', error);
  }
};