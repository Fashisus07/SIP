import { create } from 'zustand';
import { supabase } from '../lib/supabase';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  avatar_url?: string;
}

interface AuthState {
  user: User | null;
  loading: boolean;
  setUser: (user: User | null) => void;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, firstName: string, lastName: string, phone: string) => Promise<void>;
  signOut: () => Promise<void>;
  initializeAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  setUser: (user) => set({ user }),
  signIn: async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    if (data.user) {
      set({ user: {
        id: data.user.id,
        email: data.user.email!,
        firstName: data.user.user_metadata.firstName,
        lastName: data.user.user_metadata.lastName,
        phone: data.user.user_metadata.phone,
      }});
    }
  },
  signUp: async (email, password, firstName, lastName, phone) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          firstName,
          lastName,
          phone,
        },
      },
    });
    if (error) throw error;
    if (data.user) {
      set({ user: {
        id: data.user.id,
        email: data.user.email!,
        firstName: data.user.user_metadata.firstName,
        lastName: data.user.user_metadata.lastName,
        phone: data.user.user_metadata.phone,
      }});
    }
  },
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    set({ user: null });
  },
  initializeAuth: async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        set({
          user: {
            id: session.user.id,
            email: session.user.email!,
            firstName: session.user.user_metadata.firstName,
            lastName: session.user.user_metadata.lastName,
            phone: session.user.user_metadata.phone,
          }
        });
      }
    } catch (error) {
      console.error('Error initializing auth:', error);
    } finally {
      set({ loading: false });
    }
  },
}));